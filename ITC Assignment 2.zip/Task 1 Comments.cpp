#include <iostream>
using namespace std;

int main()
{
    // Variable Initialization
    int PIN = 1234;            // Default PIN for account security
    int deposit = 0;           // Variable to store deposit amount
    int balance = 0;           // Variable to store the account balance
    int temp, op = 0, draw;    // Temp for PIN verification, op for menu selection, draw for withdrawal amount
    bool account = false;      // Flag to check if the account is created

    // Main loop that keeps running until the user chooses to exit
    while (op != 5)
    {
        // Display the menu
        cout << "***** Bank Account Management System *****" << endl;
        cout << "1. Create Account (Initial Balance)" << endl;
        cout << "2. Deposit Money" << endl;
        cout << "3. Withdraw Money" << endl;
        cout << "4. Check Balance" << endl;
        cout << "5. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> op;

        // Validate the user input for menu options
        while (op > 5 || op <= 0)
        {
            cout << "Invalid Option! Try again: ";
            cin >> op;
        }

        // Option 1: Create Account
        if (op == 1)
        {
            if (account == true)
            {
                // Inform the user if an account already exists
                cout << endl << "You already have an account.\n\n";
            }
            else
            {
                // Create the account and assign an initial balance
                account = true;
                balance = 1000;
                cout << "\nYour account is created and an initial deposit of 1000$" << endl << endl;
            }
        }

        // Ensure the account is created before allowing other operations
        while (account == false)
        {
            cout << "Your account is not created." << endl << endl;

            // Display the menu again to prompt account creation
            cout << "***** Bank Account Management System *****" << endl;
            cout << "1. Create Account (Initial Balance)" << endl;
            cout << "2. Deposit Money" << endl;
            cout << "3. Withdraw Money" << endl;
            cout << "4. Check Balance" << endl;
            cout << "5. Exit" << endl;
            cout << "Enter your choice: ";
            cin >> op;

            // Create account if selected
            if (op == 1)
            {
                account = true;
                balance = 1000;
                cout << "\nYour account is created and an initial deposit of 1000$ has been alloted" << endl << endl;
            }
        }

        // Option 2: Deposit Money
        if (op == 2)
        {
            cout << "Enter an amount to deposit: ";
            cin >> deposit;

            // Validate the deposit amount (must be non-negative)
            while (deposit < 0)
            {
                cout << "Amount Invalid! Try again: ";
                cin >> deposit;
            }

            // Add the deposit to the balance
            balance += deposit;
            cout << "\n\n";
        }

        // Option 3: Withdraw Money
        if (op == 3)
        {
            // PIN verification
            cout << "Enter the PIN: " << endl;
            cin >> temp;
            while (temp != PIN)
            {
                cout << "Invalid PIN! Try again: ";
                cin >> temp;

            }

            // Enter the withdrawal amount
            cout << "Enter the amount to withdraw: ";
            cin >> draw;

            // Validate the withdrawal amount (must be non-negative and <= balance)
            while (draw < 0 || draw > balance)
            {
                cout << "Invalid Amount! Try again: ";
                cin >> draw;
            }
            // Deduct the withdrawal amount from the balance
            balance -= draw;
        }

        // Option 4: Check Balance
        if (op == 4)
        {
            // PIN verification
            cout << "Enter the PIN: " << endl;
            cin >> temp;
            while (temp != PIN)
            {
                cout << "Invalid PIN! Try again: ";
                cin >> temp;
            }
            // Display the current balance
            cout << "Your current balance is " << balance << "$\n\n";
        }
    }
    cout << "Thank You for using this atm!";
    return 0; // Exit the program
}
