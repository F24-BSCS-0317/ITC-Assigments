#include<iostream>
using namespace std;
int main()
{
	int balance, deposit, temp = 1234, withdraw = 0;         //Variable Initialization
	char create;
	do
	{
		cout << "Would you like to create an account? y/n" << endl;   //Query for Account Creation
		cin >> create;
	} while (create != 'y'&& create != 'Y' && create != 'n' && create != 'N'); //Loop for incorrect options

	if (create == 'y' || create == 'Y')          //Option Checking
	{
		balance = 1000;
		cout << "An initial balance of 1000$ has been given." << endl;   //Initial Balance
	}
	else if (create == 'n' || create == 'N')
	{ 
		balance = 0;      //Initial balance if no new account is created.
	}
	cout << "\n\n";


	do
	{
		cout << "Enter the deposit amount: ";    //Deposit amount (Not negative)
		cin >> deposit;
	} while (deposit < 0);


	balance += deposit;       //Total Balance
	cout << "Choose an option:-" << endl;
	cout << "1. Withdraw Money. \n2. Check Balance. \n3. Exit." << endl;  //Options
	int opt;
	cin >> opt;


	while (opt != 1 && opt != 2 && opt != 3)   //Loop if incorrect options selected
	{
		cout << "Choose a correct option:-" << endl;
		cout << "1. Withdraw Money. \n2. Check Balance. \n3. Exit." << endl;
		cin >> opt;
	}


	int pin = 1234;  //PIN of account


	while (opt != 3)  // Loop for option
	{
		do             //Loop for required PIN
		{
			if (temp != pin) 
			{
				cout << "Enter correct PIN." << endl;
			}
			cout << "Enter the PIN: ";
			cin >> temp;
		} while (temp != pin);

		if (balance == 0)   //If balance is 0. stop withdrawl.
		{
			cout << "Balance is 0. Cannot Withdraw." << endl;
		}

		else if (opt == 1)     //Withdrawl
		{
			do           //Loop if withdrawl amount exceeds the balance
			{
				if (withdraw > balance)  //Error Message
				{
					cout << "Withdrawn amount can't exceed the balance. " << endl;
				}

				cout << "Enter the withdraw amount: ";
				cin >> withdraw;

			} while (withdraw > balance);

			balance -= withdraw;
			cout << endl << withdraw << "$ has been withdrawn." << endl;
		}

		if (opt == 2)  //Balance Checking
		{
			cout << "Your balance is " << balance << "$" << endl;
		}

		do   //Loop if incorrect options selected
		{
			if (opt == 1 || opt == 2 || opt == 3)
			{
				cout << "Choose an option:-" << endl;
			}
			else
				cout << "Choose a correct option:-" << endl;   //Error Message

			cout << "1. Withdraw Money. \n2. Check Balance. \n3. Exit." << endl;
			cin >> opt;
		} while (opt != 1 && opt != 2 && opt != 3);
	}

	cout << endl << "Thank you for you patronage." << endl;
	return 0;
}