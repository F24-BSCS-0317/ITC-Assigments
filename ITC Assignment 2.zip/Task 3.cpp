#include<iostream>
using namespace std;
int main()
{

	//Variable Declaration

	int height, i = 0, j, k = 0;

	//Input height

	cout << "Enter the height of the first Triangle: ";
	cin >> height;
	j = height;
	do      //Main Loop to execute each row
	{
		do         //Loop for spaces
		{
			cout << " ";
			j--;
		} while (j > i);

		do    //Loop for * for each row
		{
			cout << "*";
			k++;
		} while (k <= i);
		 
		k = 0;           //k is reset at every loop itertion to make a triangle after the spaces
		j = height;             //j is reset at every loop itertion to make an inverted triagle of spaces
		cout << endl;
		i++;
	} while (i < height);

	//Variable Declaration

	int height2, l = 0, m = 1, n = 0;

	//Input height

	cout << "Enter the height of the second Triangle: ";
	cin >> height2;
	do     //Main Loop to execute each row
	{
		do    //Loop to Display the numbers in each row
		{
			cout << m;
			n++;
			m++;
		} while (n <= l);

		n = 0;      //The number of integers in a row is reset each iteration to make a triangle
		m = 1;        //The number is reset to 1 each iteration according to the question
		cout << endl;
		l++;
	} while (l < height2);




	return 0;
}