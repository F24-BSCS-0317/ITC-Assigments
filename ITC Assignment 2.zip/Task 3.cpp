#include<iostream>
using namespace std;
int main()
{

	//Variable Declaration

	int height = 5, i = 0, j, k = 0;

	cout << "The following is done with Do-While Loop: \n\n";

	//Input height

	/*cout << "Enter the height of the first Triangle: ";
	cin >> height;*/
	j = height;
	do      //Main Loop to execute each row
	{
		do         //Loop for spaces
		{
			if (j != i + 1)
			{
				cout << " ";
			}
			j--;
		} while (j > i);

		do    //Loop for * for each row
		{
			cout << "*";
			k++;
		} while (k <= i);
		 
		k = 0;           //k is reset at every loop itertion to make a triangle after the spaces
		j = height;             //j is reset at every loop itertion to make an inverted triagle of spaces
		cout << endl;
		i++;
	} while (i < height);

	//Variable Declaration

	int height2 = 5, l = 0, m = 1, n = 0;

	//Input height

	/*cout << "Enter the height of the second Triangle: ";
	cin >> height2;*/
	do     //Main Loop to execute each row
	{
		do    //Loop to Display the numbers in each row
		{
			cout << m;
			n++;
			m++;
		} while (n <= l);

		n = 0;      //The number of integers in a row is reset each iteration to make a triangle
		m = 1;        //The number is reset to 1 each iteration according to the question
		if (l != height2 - 1)
		{
			cout << endl;
		}
		l++;
	} while (l < height2);

	//Variable Declaration

	height = 5, i = 0, j, k = 1;

	cout << endl << "\nThe following is done with While Loop: " << endl;

	while (i <= height)
	{
		j = 0;            //j is reset at every loop iteration to create rows
		k = 1;            //k is reset at every iteration for the question condition
		while (j < i)
		{
			cout << k;
			k++;
			j++;
		}
		if (i != height)       //To remove the extra space at the end of the program
		{
			cout << endl;
		}
		i++;
	}

	//Variable Declaration

	height = 5, i = 0, j, k = 1;

	while (i <= height)
	{
		j = height;               //j is reset at every loop iteration to create spaces
		while (j > i)
		{
			cout << " ";
			j--;
		}
		k = 0;               //k is reset at every loop iteration to create rows
		while (k < i)
		{
			cout << "*";
			k++;
		}
		if (i != height)       //To remove the extra space at the end of the program
		{
			cout << endl;
		}
		i++;
	}


	cout << "\n\n";
	return 0;
}