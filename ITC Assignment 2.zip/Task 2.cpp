#include<iostream>
using namespace std;
int main()
{
	//Variable Initializaiton

	bool borrow1 = false, borrow2 = false, borrow3 = false, borrow5 = false;
	int op, op2;
	int cp1 = 3, cp2 = 2, cp3 = 1, cp4 = 0, cp5 = 5;

	//Intro and options

	cout << "Welcome to the Library System!" << endl;  
	cout << "Please Select an Option: \n1. Borrow a Book \n2. Return a Book \n3. Exit" << endl;
	cout << "Enter your option : ";
    cin >> op;

	//Error Loop for wrong options

	while (op != 1 && op != 2 && op != 3)   
	{
		cout << endl << "Enter a correct option : ";
		cin >> op;
	}

	while (op != 3)
	{
		if (op == 1)
		{                                              //Books to Borrow
			cout << endl << "Select a Book:- " << endl;
			cout << "1. The Catcher in the Rye - Available: " << cp1 << " copies" << endl;
			cout << "2. 1984 - Available: " << cp2 << " copies" << endl;
			cout << "3. To Kill a Mockingbird - Available: " << cp3 << " copies" << endl;
			cout << "4. The Great Gatsby - Available: " << cp4 << " copies" << endl;
			cout << "5. Moby Dick - Available: " << cp5 << " copies" << endl;

			cout << "Enter your option: ";
			cin >> op2;

			//Error Loop for wrong options

			while (op2 != 1 && op2 != 2 && op2 != 3 && op2 != 4 && op2 != 5)
			{
				cout << endl << "Enter a correct option: ";
				cin >> op2;
			}

			switch (op2)               //switch case for different books
			{                             
			case 1:
				if (borrow1 == false && cp1 != 0)    //if the books haven't been borrowed
				{
					cp1--;
					borrow1 = true;
				}
				else                     //If the books have been borrowed
					cout << "You have already borrowed this Book. Return it First." << endl;
				break;

			case 2:
				if (borrow2 == false && cp2 != 0)    //if the books haven't been borrowed
				{
					cp2--;
					borrow2 = true;
				}
				else                     //If the books have been borrowed
					cout << "You have already borrowed this Book. Return it First." << endl;
				break;

			case 3:
				if (borrow3 == false && cp3 != 0)    //if the books haven't been borrowed
				{
					cp3--;
					borrow3 = true;
				}
				else                     //If the books have been borrowed
					cout << "You have already borrowed this Book. Return it First." << endl;
				break;

			case 4:        //This Book is always out of stock
				cout << "This Book is out of Stock." << endl;
				break;

			case 5:
				if (borrow5 == false && cp5 != 0)    //if the books haven't been borrowed
				{
					cp5--;
					borrow5 = true;
				}
				else                     //If the books have been borrowed
					cout << "You have already borrowed this Book. Return it First." << endl;
				break;
			}
		}
		if (op == 2)              //Books to Return
		{
			cout << endl << "Select a Book:- " << endl;
			cout << "1. The Catcher in the Rye - Available: " << cp1 << " copies" << endl;
			cout << "2. 1984 - Available: " << cp2 << " copies" << endl;
			cout << "3. To Kill a Mockingbird - Available: " << cp3 << " copies" << endl;
			cout << "4. The Great Gatsby - Available: " << cp4 << " copies" << endl;
			cout << "5. Moby Dick - Available: " << cp5 << " copies" << endl;

			cout << "Enter the book you wish to return: ";
			cin >> op2;

			//Error Loop for wrong options

			while (op2 != 1 && op2 != 2 && op2 != 3 && op2 != 4 && op2 != 5)
			{
				cout << endl << "Enter a correct option: ";
				cin >> op2;
			}

			if (op2 == 1)           //If statement to return books
			{
				if (borrow1 == true)        //If the books have been borrowed
				{
					borrow1 = false;
					cout << "The book has been returned. Thank You! " << endl;
					cp1++;
				}
				else          //If the books haven't been borrowed
					cout << "You have not borrowed this book." << endl;
			}
			if (op2 == 2)        //If the books have been borrowed
			{
				if (borrow2 == true)
				{
					borrow2 = false;
					cout << "The book has been returned. Thank You! " << endl;
					cp2++;
				}
				else          //If the books haven't been borrowed
					cout << "You have not borrowed this book." << endl;
			}
			if (op2 == 3)        //If the books have been borrowed
			{
				if (borrow3 == true)
				{
					borrow3 = false;
					cout << "The book has been returned. Thank You! " << endl;
					cp3++;
				}
				else          //If the books haven't been borrowed
					cout << "You have not borrowed this book." << endl;
			}
			if (op2 == 4)   //This book is always Out-Of-Stock
			{
				cout << "This book is out of stock." << endl;
			}
			if (op2 == 5)        //If the books have been borrowed
			{
				if (borrow5 == true)
				{
					borrow5 = false;
					cout << "The book has been returned. Thank You! " << endl;
					cp5++;
				}
				else          //If the books haven't been borrowed
					cout << "You have not borrowed this book." << endl;
			}

		}

		//Options to redo the loop

		cout << "\n\n";
		cout << "Please Select an Option: \n1. Borrow a Book \n2. Return a Book \n3. Exit" << endl;
		cout << "Enter your option : ";
		cin >> op;

		//Error Loop for wrong options

		while (op != 1 && op != 2 && op != 3)
		{
			cout << endl << "Enter a correct option : ";
			cin >> op;
		}
	}


	return 0;
}