#include<iostream>
using namespace std;
int main()
{
	//Array Declaration

	int student1[3] = { 85,92,78 }, student2[3] = { 88,79,90 }, student3[3] = { 91,85,80 };
	int student4[3] = { 77,88,92 }, student5[3] = { 85,80,87 };
	double total[5], average[5];

	//Integers to store Highest, Lowest and Class Average Marks

	int high = 0, low = 100;
	double avg = 0;

	//Printing a Matrix

	cout << "Grades Matrix (Student vs Subject):" << endl;

	for (int i = 0; i < 3; i++)   //Student 1 Row
	{
		cout << "Student 1, Subject" << i + 1 << ": " << student1[i] << "\t\t";
	}cout << endl;

	for (int i = 0; i < 3; i++)   //Student 2 Row
	{
		cout << "Student 2, Subject" << i + 1 << ": " << student2[i] << "\t\t";
	}cout << endl;

	for (int i = 0; i < 3; i++)   //Student 3 Row
	{
		cout << "Student 3, Subject" << i + 1 << ": " << student3[i] << "\t\t";
	}cout << endl;

	for (int i = 0; i < 3; i++)   //Student 4 Row
	{
		cout << "Student 4, Subject" << i + 1 << ": " << student4[i] << "\t\t";
	}cout << endl;

	for (int i = 0; i < 3; i++)   //Student 5 Row
	{
		cout << "Student 5, Subject" << i + 1 << ": " << student5[i] << "\t\t";
	}cout << endl;

	//Calculating Total and Average of Each student

	for (int i = 0; i < 5; i++)     //Loop to cycle each student
	{
		total[i] = 0;
		for (int j = 0; j < 3; j++)  //Loop to cycle each subject
		{
			if (i == 0)
			{
				total[i] += student1[j];  //  Array to calculate total for each student
				if (student1[j] > high)  //  Condition to Check for Highest Marks
				{
					high = student1[j];
				}
				if (student1[j] < low)  //  Condition to Check for Lowest Marks
				{
					low = student1[j];
				}
			}
			if (i == 1)
			{
				total[i] += student2[j];  //  Array to calculate total for each student
				if (student2[j] > high)  //  Condition to Check for Highest Marks
				{
					high = student2[j];
				}
				if (student2[j] < low)  //  Condition to Check for Lowest Marks
				{
					low = student2[j];
				}
			}
			if (i == 2)
			{
				total[i] += student3[j];  //  Array to calculate total for each student
				if (student3[j] > high)  //  Condition to Check for Highest Marks
				{
					high = student3[j];
				}
				if (student3[j] < low)  //  Condition to Check for Lowest Marks
				{
					low = student3[j];
				}
			}
			if (i == 3)
			{
				total[i] += student4[j];  //  Array to calculate total for each student
				if (student4[j] > high)  //  Condition to Check for Highest Marks
				{
					high = student4[j];
				}
				if (student4[j] < low)  //  Condition to Check for Lowest Marks
				{
					low = student4[j];
				}
			}
			if (i == 4)
			{
				total[i] += student5[j];  //  Array to calculate total for each student
				if (student5[j] > high)  //  Condition to Check for Highest Marks
				{
					high = student5[j];
				}
				if (student5[j] < low)  //  Condition to Check for Lowest Marks
				{
					low = student5[j];
				}
			}
		}
		average[i] = total[i] / 3;  //  Average For Each Student
		avg += total[i];  //  Total Marks of the Class
	}
	avg /= 15;  //  Total Marks / (Students * Subjects) = Class Average 

	//Displaying Total and Average Marks of Students

	cout <<"\n\nTotal Marks and Averages for Each Student: " << endl;
	for (int i = 0; i < 5; i++)  //  Loop to Display the Total Marks and Average of Each Student
	{
		cout << "Student" << i+1 <<" :  Total Marks = " << total[i] << ",  Average = " << average[i] << endl;
	}

	//Displaying for Highest, Lowest and Class Average Marks

	cout << "\n\nClass Average: " << avg << endl;
	cout << "Highest Marks in Class: " << high << endl;
	cout << "Lowest Marks in Class: " << low << endl;
	return 0;
}