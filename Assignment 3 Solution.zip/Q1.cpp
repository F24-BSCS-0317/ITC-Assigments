#include<iostream>
using namespace std;
int main()
{
	//Array Declaration of 10 Integers

	int arr[10] = { 1,2,3,4,5,6,7,8,9,10 };

	//Initialization of the variable to store the sum

	int sum = 0;

	//Calculate Sum

	for (int i = 0; i < 10; i++)
	{
		sum += arr[i];
	}

	//Output of the Sum

	cout << endl << "The sum of all the Elements is " << sum << endl;

	//Traversal from Left to Right

	cout << "The array from left to right is: ";
	for (int i = 0; i < 10; i++)
	{
		cout << arr[i] << " ";
	}cout << endl;

	//Traversal from Right to Left

	cout << "The array from right to left is: ";
	for (int i = 10 - 1; i >= 0; i--)
	{
		cout << arr[i] << " ";
	}cout << endl;

	return 0;
}