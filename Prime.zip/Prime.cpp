#include<iostream>
using namespace std;
int main()
{
	int num = 99, count = 0;   //Variable Initialization
	for (int j = 2; j <= num; j++)     // first loop to check all numbers from 2 to 99 
	{
		for (int i = 2; i < j; i++)    // second loop to check if the numebr is prime by dividing it with all numbers between itself and 1
		{
			if (j % i == 0)
			{
				count++;     //counter to check if the number has been successfully divided
			}
		}
		if (count == 0)  // checks whether the number has been divided or not 
		{
			cout << j << " ";
		}
		count = 0;   // counter resets for each loop
	}

	cout << "\n\n";  //Line spacing for asthetics
	return 0;
}